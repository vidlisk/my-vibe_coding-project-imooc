---
name: Precision Ledger
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#434655'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#784b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#996100'
  on-tertiary-container: '#ffeedd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
  expense-red: '#EF4444'
  income-green: '#10B981'
  warning-yellow: '#F59E0B'
  text-primary: '#111827'
  text-secondary: '#4B5563'
  border-subtle: '#E5E7EB'
typography:
  display-amount:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  max-width: 1280px
---

## Brand & Style
The design system is anchored in the "Speed-to-Action" philosophy, prioritizing the rapid entry of financial data. The brand personality is **Efficient, Transparent, and Reliable**, catering to users who value clarity over decoration. 

The chosen style is **Modern Corporate Minimalism**. It utilizes a clean, systematic layout with ample whitespace to reduce cognitive load during financial management. While the structure is professional and grounded, soft rounded corners and a refined color palette introduce an approachable, "friendly-finance" feel. The interface is intentionally "utility-first," designed to help users complete a transaction entry in under 5 seconds.

## Colors
The color strategy employs **Finance Blue (#2563EB)** as the primary brand anchor, signaling trust and stability. Functional colors are strictly mapped to financial states: 
- **Income-Green** represents positive flow and successful growth.
- **Expense-Red** identifies outflows and budget overages.
- **Warning-Yellow** serves as a threshold indicator for budget alerts (80%+).

The background uses a crisp **Neutral (#F9FAFB)** to ensure high legibility of data points. Subtle grays are used for secondary metadata and borders, maintaining a hierarchical distinction between the interface "frame" and the critical financial data.

## Typography
**Inter** is selected for its exceptional readability and neutral, professional character. It excels in data-heavy environments, particularly with numerical alignment.

The hierarchy is dominated by the **Display Amount** level, designed for the primary input field where speed and accuracy are paramount. For localization, the system pairs Inter with **PingFang SC** for Chinese characters, ensuring consistent weight matching and legibility. Numbers should use tabular figures where possible in lists to ensure currency symbols and decimals align vertically for easier scanning.

## Layout & Spacing
The layout follows a **Mobile-First Responsive** philosophy. 

- **Mobile (< 768px):** A single-column fluid layout focused on thumb-reachability. A bottom navigation bar provides instant access to core functions.
- **Desktop (≥ 768px):** A fixed sidebar navigation (240px width) combined with a flexible main content area. Content is centered with a max-width of 1280px to prevent excessive line lengths.

A strictly enforced **8px grid system** (using the 4px base unit) dictates all padding and margins, ensuring a rhythmic and balanced distribution of elements. Transaction lists use a "Day-Grouped" structure with 16px vertical spacing between groups and 1px borders between individual items.

## Elevation & Depth
This design system uses **Tonal Layers** rather than heavy shadows to maintain a minimalist aesthetic. 

- **Level 0 (Surface):** The main background (#F9FAFB).
- **Level 1 (Cards/Containers):** Pure white (#FFFFFF) surfaces with a 1px subtle border (#E5E7EB) to define boundaries.
- **Level 2 (Overlays):** Used for Bottom Sheets and Modals. These use a very soft, diffused ambient shadow (10% opacity, 12px blur) to suggest height without appearing heavy.
- **Backdrop:** A 40% opacity neutral tint is used behind modals to focus the user’s attention on the action at hand.

## Shapes
A **Rounded (0.5rem / 8px)** base is applied to standard components like input fields and small cards. For larger containers and prominent mobile elements (like the record-entry bottom sheet), the system scales to **rounded-lg (16px)** to create a more modern, friendly, and touch-optimized appearance.

Buttons and category icons use a high degree of roundedness to appear as distinct, tappable targets, contrasting with the more structured, rectangular nature of the transaction list rows.

## Components

### Buttons
- **Primary:** High-contrast Blue (#2563EB) with white text. 12px-16px internal padding.
- **Category Icons:** Circular or highly rounded squares with colored backgrounds and minimalist line icons. In the "Save on Select" flow, these act as the primary submission trigger.

### Input Fields
- **Amount Input:** The hero of the Record page. Borderless or underline-only styling with a large font size. Includes a clear "¥" prefix.
- **Standard Inputs:** 12px vertical padding, 8px rounded corners, with a clear focus state using the Primary Blue border.

### Cards & Lists
- **Transaction Item:** A horizontal layout with the category icon on the left, label/note in the center, and amount on the right. Amounts are color-coded based on the "Income" or "Expense" status.
- **Budget Progress Bar:** Rounded track with a primary color fill that transitions to Yellow at 80% and Red at 100%.

### Feedback & Navigation
- **Bottom Navigation:** Fixed on mobile, containing 4 clear icons with text labels for "Record," "Bills," "Statistics," and "Profile."
- **Toasts:** Brief, non-obstructive notifications at the top of the screen confirming "Entry Saved."